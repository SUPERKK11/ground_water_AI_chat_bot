version: "3.0"
nlu:
- intent: greet
  examples: |
    - hello
    - hi
    - hey
    - good morning
    - good evening

- intent: ask_groundwater_info
  examples: |
    - Tell me about groundwater
    - What is groundwater?
    - Can you explain what groundwater is?
    - I want to know about groundwater

- intent: ask_groundwater_quality
  examples: |
    - What is the quality of groundwater?
    - How is the groundwater quality in this area?
    - Is the groundwater safe to drink?

- intent: ask_groundwater_levels
  examples: |
    - What are the groundwater levels?
    - How high are the groundwater levels?
    - Tell me about the groundwater levels

- intent: goodbye
  examples: |
    - bye
    - goodbye
    - see you later

version: "3.0"
stories:
- story: greet user
  steps:
  - intent: greet
  - action: utter_greet

- story: provide groundwater information
  steps:
  - intent: ask_groundwater_info
  - action: utter_groundwater_info

- story: provide groundwater quality
  steps:
  - intent: ask_groundwater_quality
  - action: utter_groundwater_quality

- story: provide groundwater levels
  steps:
  - intent: ask_groundwater_levels
  - action: utter_groundwater_levels

- story: say goodbye
  steps:
  - intent: goodbye
  - action: utter_goodbye
