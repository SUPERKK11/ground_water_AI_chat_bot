function sendMessage() {
    const userInput = document.getElementById('userInput');
    const userMessage = userInput.value.trim();

    // If the input is empty, don't send a message
    if (userMessage === '') return;

    // Get the messages container
    const messages = document.getElementById('messages');

    // Append the user message
    const userMessageDiv = document.createElement('div');
    userMessageDiv.className = 'message user';
    userMessageDiv.innerHTML = `<div class="content">${userMessage}</div>`;
    messages.appendChild(userMessageDiv);

    // Clear the input field
    userInput.value = '';

    // Scroll to the bottom of the messages container
    messages.scrollTop = messages.scrollHeight;

    // Send the message to the Flask backend
    fetch('/chatbot', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: userMessage })
    })
    .then(response => response.json())
    .then(data => {
        const botMessageDiv = document.createElement('div');
        botMessageDiv.className = 'message bot';
        botMessageDiv.innerHTML = `<div class="content">${data.response}</div>`;
        messages.appendChild(botMessageDiv);

        // Scroll to the bottom of the messages container
        messages.scrollTop = messages.scrollHeight;
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

