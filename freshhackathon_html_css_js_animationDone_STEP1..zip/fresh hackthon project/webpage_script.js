//gsap
// landing page animation
gsap.to("#nav",{
    height:"80px",
    duration:0.5,
    scrollTrigger:{
        // for trigger action 
        trigger:"#nav",
        scroller:"body",
        // for seting  from where to where, we need to perform that action point.
        start:"top -10%",
        end:"top -40%",
        scrub:1//for xmooth animation 
    }
})
