function sendMessage() {
    const userInput = document.getElementById('userInput');
    const userMessage = userInput.value.trim();

    if (userMessage === '') return;

    const messages = document.getElementById('messages');

    const userMessageDiv = document.createElement('div');
    userMessageDiv.className = 'message user';
    userMessageDiv.innerHTML = `<div class="content">${userMessage}</div>`;
    messages.appendChild(userMessageDiv);

    userInput.value = '';

    // Scroll to the bottom of the messages container
    messages.scrollTop = messages.scrollHeight;

    setTimeout(() => {
        const botMessageDiv = document.createElement('div');
        botMessageDiv.className = 'message bot';
        botMessageDiv.innerHTML = `<div class="content">I'm your Water Buddy! How can I help you with groundwater information?</div>`;
        messages.appendChild(botMessageDiv);

        messages.scrollTop = messages.scrollHeight;
    }, 500);
}

function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

document.getElementById('userInput').addEventListener('keypress', handleKeyPress);
document.querySelector('button').addEventListener('click', sendMessage);
